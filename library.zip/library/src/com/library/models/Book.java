package com.library.models;



public class Book {
    private int id;
    private String title;
    private String author;
    private String status;
    private int publishedYear;

    public Book(int id, String title, String author, String status, int publishedYear) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.status = status;
        this.publishedYear = publishedYear;
    }

    // Getters and setters
}
