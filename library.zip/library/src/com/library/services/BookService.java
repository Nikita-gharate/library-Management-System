package com.library.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.library.db.DatabaseConnector;
import com.library.models.Book;

public class BookService {
    public List<Book> getAllBooks() throws Exception {
        Connection connection = DatabaseConnector.getConnection();
        String query = "SELECT * FROM books";
        PreparedStatement ps = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        List<Book> books = new ArrayList<>();
        while (rs.next()) {
            books.add(new Book(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getString("status"),
                rs.getInt("published_year")
            ));
        }
        return books;
    }
}