package com.library.auth;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.library.db.DatabaseConnector;
import org.mindrot.jbcrypt.BCrypt;

public class Auth {
    public String login(String username, String password) throws Exception {
        Connection connection = DatabaseConnector.getConnection();
        String query = "SELECT password, role FROM users WHERE username = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();

        if (rs.next() && BCrypt.checkpw(password, rs.getString("password"))) {
            return JwtTokenUtil.generateToken(username, rs.getString("role"));
        }
        return null;
    }

    public boolean register(String username, String password, String role) throws Exception {
        Connection connection = DatabaseConnector.getConnection();
        String query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1, username);
        ps.setString(2, BCrypt.hashpw(password, BCrypt.gensalt()));
        ps.setString(3, role);

        return ps.executeUpdate() > 0;
    }
}
