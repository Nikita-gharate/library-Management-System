

import com.library.auth.Auth;

public class Main {
    public static void main(String[] args) {
        Auth auth = new Auth();
        try {
            // Example usage
            String token = auth.login("admin", "password123");
            if (token != null) {
                System.out.println("Login successful! Token: " + token);
            } else {
                System.out.println("Invalid credentials.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
